$('.table tbody').on('click','btn',function() {
	$(this).closest('tr').remove();
});

.next().remove(); or .prev().remove();

KauTube.com